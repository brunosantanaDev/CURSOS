console.log(typeof Array.fromjdhsjkah !== "undefined")

if(typeof Array.fromjdhsjkah !== "undefined") {
  console.log('Existe')
} else {
  console.log('Não existe')
}

