import React from 'react';

const Header = () => {
  return <header>Header</header>;
};

export default Header;
